python plot_figs.py li
python plot_figs.py l2_coarse
python plot_figs.py l2_fine
python plot_figs.py pgd
