#li
python stats.py whitebox_eval_large_triplet-small_center_vgg-cw_li.csv li
python stats.py whitebox_eval_large_triplet-large_center_casia-cw_li.csv li
python stats.py whitebox_eval_casia-large_triplet_vgg-cw_li.csv li
python stats.py whitebox_eval_casia-small_center_vgg-cw_li.csv li
python stats.py whitebox_eval_large_triplet-small_triplet_vgg-cw_li.csv li
python stats.py whitebox_eval_casia-large_center_vgg-cw_li.csv li
python stats.py whitebox_eval_large_triplet-large_center_vgg-cw_li.csv li


#l2_fine
python stats.py whitebox_eval_large_triplet-large_center_vgg-cw_l2.csv l2_fine
python stats.py whitebox_eval_large_triplet-large_center_casia-cw_l2.csv l2_fine
python stats.py whitebox_eval_large_triplet-small_center_vgg-cw_l2.csv l2_fine
python stats.py whitebox_eval_large_triplet-small_triplet_vgg-cw_l2.csv l2_fine


#l2_coarse
python stats.py whitebox_eval_large_triplet-large_center_vgg-cw_l2.csv l2_coarse
python stats.py whitebox_eval_large_center-small_triplet_vgg-cw_l2.csv l2_coarse
python stats.py whitebox_eval_casia-large_triplet_vgg-cw_l2.csv l2_coarse
python stats.py whitebox_eval_large_triplet-large_center_casia-cw_l2.csv l2_coarse
python stats.py whitebox_eval_large_triplet-small_center_vgg-cw_l2.csv l2_coarse
python stats.py whitebox_eval_casia-large_center_vgg-cw_l2.csv l2_coarse
python stats.py whitebox_eval_large_center-large_center_casia-cw_l2.csv l2_coarse
python stats.py whitebox_eval_large_center-large_triplet_vgg-cw_l2.csv l2_coarse
python stats.py whitebox_eval_large_center-small_center_vgg-cw_l2.csv l2_coarse
python stats.py whitebox_eval_casia-small_triplet_vgg-cw_l2.csv l2_coarse
python stats.py whitebox_eval_large_triplet-small_triplet_vgg-cw_l2.csv l2_coarse


#pgd
python stats.py whitebox_eval_large_triplet-large_center_vgg-pgd_l2.csv pgd
python stats.py whitebox_eval_large_center-large_center_casia-pgd_l2.csv pgd
python stats.py whitebox_eval_large_center-small_center_vgg-pgd_l2.csv pgd
python stats.py whitebox_eval_large_center-large_triplet_vgg-pgd_l2.csv pgd
python stats.py whitebox_eval_large_triplet-small_triplet_vgg-pgd_l2.csv pgd
python stats.py whitebox_eval_casia-large_center_vgg-pgd_l2.csv pgd
python stats.py whitebox_eval_small_triplet-large_triplet_vgg-pgd_l2.csv pgd
python stats.py whitebox_eval_small_triplet-large_center_vgg-pgd_l2.csv pgd
python stats.py whitebox_eval_large_center-small_triplet_vgg-pgd_l2.csv pgd
python stats.py whitebox_eval_large_triplet-small_center_vgg-pgd_l2.csv pgd
python stats.py whitebox_eval_small_center-large_center_vgg-pgd_l2.csv pgd
python stats.py whitebox_eval_small_triplet-small_center_vgg-pgd_l2.csv pgd
python stats.py whitebox_eval_large_triplet-large_center_casia-pgd_l2.csv pgd
python stats.py whitebox_eval_small_triplet-large_center_casia-pgd_l2.csv pgd
python stats.py whitebox_eval_small_center-large_triplet_vgg-pgd_l2.csv pgd
python stats.py whitebox_eval_small_center-large_center_casia-pgd_l2.csv pgd
python stats.py whitebox_eval_casia-small_triplet_vgg-pgd_l2.csv pgd
python stats.py whitebox_eval_casia-large_triplet_vgg-pgd_l2.csv pgd


