import Config


s3_bucket_url = ''
s3_bucket_name = ''
aws_region = ''


# credentials = 0
# azure
FaceID_endpoint = ''
FaceID_key = ''
# aws rekognition
aws_access_key_id = ''
aws_secret_access_key = ''
# face++
facepp_api_key = ''
facepp_api_sec = ''



# credentials = 1
# face++
facepp_api_key_new = ''
facepp_api_sec_new = ''
# aws rekognition
aws_access_key_id_new = ''
aws_secret_access_key_new = ''
# azure
azure_key = ''
