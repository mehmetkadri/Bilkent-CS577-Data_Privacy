#facepp
python read_and_plot.py facepp cw_l2 large_triplet >> facepp_table.txt
python read_and_plot.py facepp cw_l2 small_center >> facepp_table.txt
python read_and_plot.py facepp cw_l2 large_center >> facepp_table.txt
python read_and_plot.py facepp cw_l2 casia >> facepp_table.txt
python read_and_plot.py facepp cw_l2 small_triplet >> facepp_table.txt
python read_and_plot.py facepp cw_li large_triplet >> facepp_table.txt
python read_and_plot.py facepp cw_li small_center >> facepp_table.txt
python read_and_plot.py facepp cw_li large_center >> facepp_table.txt
python read_and_plot.py facepp cw_li casia >> facepp_table.txt
python read_and_plot.py facepp cw_li small_triplet >> facepp_table.txt
python read_and_plot.py facepp pgd_l2 large_triplet >> facepp_table.txt
python read_and_plot.py facepp pgd_l2 small_center >> facepp_table.txt
python read_and_plot.py facepp pgd_l2 large_center >> facepp_table.txt
python read_and_plot.py facepp pgd_l2 casia >> facepp_table.txt
python read_and_plot.py facepp pgd_l2 small_triplet >> facepp_table.txt


#azure
python read_and_plot.py azure cw_l2 large_triplet >> azure_table.txt
python read_and_plot.py azure cw_l2 small_center >> azure_table.txt
python read_and_plot.py azure cw_l2 large_center >> azure_table.txt
python read_and_plot.py azure cw_l2 casia >> azure_table.txt
python read_and_plot.py azure cw_l2 small_triplet >> azure_table.txt
python read_and_plot.py azure cw_li large_triplet >> azure_table.txt
python read_and_plot.py azure cw_li small_center >> azure_table.txt
python read_and_plot.py azure cw_li large_center >> azure_table.txt
python read_and_plot.py azure cw_li casia >> azure_table.txt
python read_and_plot.py azure cw_li small_triplet >> azure_table.txt
python read_and_plot.py azure pgd_l2 large_triplet >> azure_table.txt
python read_and_plot.py azure pgd_l2 small_center >> azure_table.txt
python read_and_plot.py azure pgd_l2 large_center >> azure_table.txt
python read_and_plot.py azure pgd_l2 casia >> azure_table.txt
python read_and_plot.py azure pgd_l2 small_triplet >> azure_table.txt


#awsverify
python read_and_plot.py awsverify cw_l2 large_triplet >> awsverify_table.txt
python read_and_plot.py awsverify cw_l2 small_center >> awsverify_table.txt
python read_and_plot.py awsverify cw_l2 large_center >> awsverify_table.txt
python read_and_plot.py awsverify cw_l2 casia >> awsverify_table.txt
python read_and_plot.py awsverify cw_l2 small_triplet >> awsverify_table.txt
python read_and_plot.py awsverify cw_li large_triplet >> awsverify_table.txt
python read_and_plot.py awsverify cw_li small_center >> awsverify_table.txt
python read_and_plot.py awsverify cw_li large_center >> awsverify_table.txt
python read_and_plot.py awsverify cw_li casia >> awsverify_table.txt
python read_and_plot.py awsverify cw_li small_triplet >> awsverify_table.txt
python read_and_plot.py awsverify pgd_l2 large_triplet >> awsverify_table.txt
python read_and_plot.py awsverify pgd_l2 small_center >> awsverify_table.txt
python read_and_plot.py awsverify pgd_l2 large_center >> awsverify_table.txt
python read_and_plot.py awsverify pgd_l2 casia >> awsverify_table.txt
python read_and_plot.py awsverify pgd_l2 small_triplet >> awsverify_table.txt


