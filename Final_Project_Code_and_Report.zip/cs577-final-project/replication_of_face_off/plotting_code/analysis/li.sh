#li
python stats.py whitebox_eval_large_triplet-small_center_vgg-cw_li.csv li
python stats.py whitebox_eval_large_triplet-large_center_casia-cw_li.csv li
python stats.py whitebox_eval_casia-large_triplet_vgg-cw_li.csv li
python stats.py whitebox_eval_casia-small_center_vgg-cw_li.csv li
python stats.py whitebox_eval_large_triplet-small_triplet_vgg-cw_li.csv li
python stats.py whitebox_eval_casia-large_center_vgg-cw_li.csv li
python stats.py whitebox_eval_large_triplet-large_center_vgg-cw_li.csv li


