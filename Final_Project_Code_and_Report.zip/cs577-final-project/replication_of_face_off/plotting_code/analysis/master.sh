sh parse_csv.sh
sh plot.sh
rm -rf txt
