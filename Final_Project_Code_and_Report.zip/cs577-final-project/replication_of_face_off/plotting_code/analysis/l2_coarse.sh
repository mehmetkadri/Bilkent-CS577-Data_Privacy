#l2_coarse
python stats.py whitebox_eval_large_triplet-large_center_vgg-cw_l2.csv l2_coarse
python stats.py whitebox_eval_large_center-small_triplet_vgg-cw_l2.csv l2_coarse
python stats.py whitebox_eval_casia-large_triplet_vgg-cw_l2.csv l2_coarse
python stats.py whitebox_eval_large_triplet-large_center_casia-cw_l2.csv l2_coarse
python stats.py whitebox_eval_large_triplet-small_center_vgg-cw_l2.csv l2_coarse
python stats.py whitebox_eval_casia-large_center_vgg-cw_l2.csv l2_coarse
python stats.py whitebox_eval_large_center-large_center_casia-cw_l2.csv l2_coarse
python stats.py whitebox_eval_large_center-large_triplet_vgg-cw_l2.csv l2_coarse
python stats.py whitebox_eval_large_center-small_center_vgg-cw_l2.csv l2_coarse
python stats.py whitebox_eval_casia-small_triplet_vgg-cw_l2.csv l2_coarse
python stats.py whitebox_eval_large_triplet-small_triplet_vgg-cw_l2.csv l2_coarse


