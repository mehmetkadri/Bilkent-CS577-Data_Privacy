sh li.sh
sh pgd.sh
sh l2_coarse.sh
sh l2_fine.sh

