python stats.py csv/whitebox_eval_large_center-large_center_casia-cw_l2.csv all all
python stats.py csv/whitebox_eval_large_center-large_triplet_vgg-cw_l2.csv all all
python stats.py csv/whitebox_eval_large_center-large_triplet_vgg-cw_l2_tv.csv all all
python stats.py csv/whitebox_eval_large_triplet-large_center_casia-cw_l2.csv all all
python stats.py csv/whitebox_eval_large_triplet-large_center_vgg-cw_l2.csv all all

python stats.py csv/whitebox_eval_large_center-small_triplet_vgg-cw_l2.csv all all
python stats.py csv/whitebox_eval_large_center-small_center_vgg-cw_l2.csv all all
python stats.py csv/whitebox_eval_large_triplet-small_center_vgg-cw_l2.csv all all
python stats.py csv/whitebox_eval_large_triplet-small_center_vgg-cw_li.csv all all
python stats.py csv/whitebox_eval_large_triplet-small_triplet_vgg-cw_l2.csv all all
