#l2_fine
python stats.py whitebox_eval_large_triplet-large_center_vgg-cw_l2.csv l2_fine
python stats.py whitebox_eval_large_triplet-large_center_casia-cw_l2.csv l2_fine
python stats.py whitebox_eval_large_triplet-small_center_vgg-cw_l2.csv l2_fine
python stats.py whitebox_eval_large_triplet-small_triplet_vgg-cw_l2.csv l2_fine



