from setuptools import find_packages
from setuptools import setup

setup(name='faceoff',
	  version='1.0',
	  url='https://github.com/kmfawaz/AdvFace',
	  license='MIT',
	  install_requires=[
	  ],
	  packages=find_packages())
